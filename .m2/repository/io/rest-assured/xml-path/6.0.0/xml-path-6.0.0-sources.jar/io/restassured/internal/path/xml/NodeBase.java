package io.restassured.internal.path.xml;

public abstract class NodeBase
  extends java.lang.Object  implements
    io.restassured.path.xml.element.PathElement,    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
@java.lang.Override() public abstract  java.lang.Object get(java.lang.String name);
public abstract <T> java.util.List<T> getList(java.lang.String name);
protected static <T> T get(java.lang.String name, java.lang.Object iterator, boolean forceList) { return null; }
public abstract  java.lang.Object getPath(java.lang.String path);
@java.lang.Override() public  java.lang.Object getPath(java.lang.String path, java.lang.Class explicitType) { return null; }
public  io.restassured.path.xml.element.Node getNode(java.lang.String name) { return null; }
public  java.util.List<io.restassured.path.xml.element.Node> getNodes(java.lang.String name) { return null; }
public abstract  java.lang.Object getBackingGroovyObject();
}
