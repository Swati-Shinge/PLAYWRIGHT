package io.restassured.internal.path.xml.mapping;

public class XmlPathJakartaEEObjectDeserializer
  extends java.lang.Object  implements
    io.restassured.path.xml.mapping.XmlPathObjectDeserializer,    groovy.lang.GroovyObject {
;
public XmlPathJakartaEEObjectDeserializer(io.restassured.path.xml.mapper.factory.JakartaEEObjectMapperFactory factory) {}
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
@java.lang.SuppressWarnings(value="UnnecessaryQualifiedReference") @java.lang.Override() public  java.lang.Object deserialize(io.restassured.common.mapper.ObjectDeserializationContext context) { return null; }
}
