package io.restassured.internal.path.xml;

public class XmlPrettifier
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
public static  java.lang.String prettify(groovy.xml.XmlParser xmlParser, java.lang.Object xml) { return null; }
public static  java.lang.String prettify(groovy.xml.slurpersupport.GPathResult gPathResult) { return null; }
}
