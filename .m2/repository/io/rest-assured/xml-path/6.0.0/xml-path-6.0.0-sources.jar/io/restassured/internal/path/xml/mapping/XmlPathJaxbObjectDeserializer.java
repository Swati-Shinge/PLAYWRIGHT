package io.restassured.internal.path.xml.mapping;

public class XmlPathJaxbObjectDeserializer
  extends java.lang.Object  implements
    io.restassured.path.xml.mapping.XmlPathObjectDeserializer,    groovy.lang.GroovyObject {
;
public XmlPathJaxbObjectDeserializer(io.restassured.path.xml.mapper.factory.JAXBObjectMapperFactory factory) {}
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
@java.lang.SuppressWarnings(value="UnnecessaryQualifiedReference") @java.lang.Override() public  java.lang.Object deserialize(io.restassured.common.mapper.ObjectDeserializationContext context) { return null; }
}
