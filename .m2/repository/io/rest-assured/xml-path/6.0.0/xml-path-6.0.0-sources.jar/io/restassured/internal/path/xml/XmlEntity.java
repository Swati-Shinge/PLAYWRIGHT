package io.restassured.internal.path.xml;
import static io.restassured.internal.common.assertion.AssertionSupport.*;

public class XmlEntity
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
@groovy.transform.Generated() public  java.lang.Object getChildren() { return null; }
@groovy.transform.Generated() public  void setChildren(java.lang.Object value) { }
@groovy.transform.Generated() public  java.lang.Object getAttributes() { return null; }
@groovy.transform.Generated() public  void setAttributes(java.lang.Object value) { }
}
