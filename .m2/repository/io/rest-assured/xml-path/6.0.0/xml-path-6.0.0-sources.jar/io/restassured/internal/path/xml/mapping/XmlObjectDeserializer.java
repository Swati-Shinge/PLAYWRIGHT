package io.restassured.internal.path.xml.mapping;

public class XmlObjectDeserializer
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
public static <T> T deserialize(java.lang.String xml, java.lang.Class<T> cls, io.restassured.path.xml.config.XmlPathConfig xmlPathConfig) { return null; }
public static  java.lang.Object deserializeWithJaxb(io.restassured.common.mapper.ObjectDeserializationContext ctx, io.restassured.path.xml.mapper.factory.JAXBObjectMapperFactory factory) { return null; }
}
