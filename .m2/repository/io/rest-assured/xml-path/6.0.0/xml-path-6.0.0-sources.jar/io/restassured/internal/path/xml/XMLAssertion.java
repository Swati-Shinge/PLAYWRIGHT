package io.restassured.internal.path.xml;
import static io.restassured.internal.common.assertion.AssertionSupport.*;

public class XMLAssertion
  extends java.lang.Object  implements
    io.restassured.internal.common.assertion.Assertion,    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
@groovy.transform.Generated() public  java.lang.String getKey() { return null; }
@groovy.transform.Generated() public  void setKey(java.lang.String value) { }
@groovy.transform.Generated() public  java.util.Map<java.lang.String, java.lang.Object> getParams() { return null; }
@groovy.transform.Generated() public  void setParams(java.util.Map<java.lang.String, java.lang.Object> value) { }
public  java.lang.Object getResult(java.lang.Object object, boolean shouldConvertToJavaObject, boolean rootEvaluation) { return null; }
public  java.lang.Object getResult(java.lang.Object object, java.lang.Object config) { return null; }
public  java.lang.Object getChildResultAsJavaObject(java.lang.Object object) { return null; }
public  boolean isPathFragment(java.lang.String fragment) { return false; }
public  java.lang.String description() { return null; }
}
