package io.restassured.internal.multipart;

@groovy.transform.Canonical() public class MultiPartInternal
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
;
public static final java.lang.String OCTET_STREAM = "application/octet-stream";
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
@groovy.transform.Generated() public  java.lang.Object getContent() { return null; }
@groovy.transform.Generated() public  void setContent(java.lang.Object value) { }
@groovy.transform.Generated() public  java.lang.String getControlName() { return null; }
@groovy.transform.Generated() public  void setControlName(java.lang.String value) { }
@groovy.transform.Generated() public  java.lang.String getFileName() { return null; }
@groovy.transform.Generated() public  void setFileName(java.lang.String value) { }
@groovy.transform.Generated() public  void setMimeType(java.lang.String value) { }
@groovy.transform.Generated() public  java.lang.String getCharset() { return null; }
@groovy.transform.Generated() public  void setCharset(java.lang.String value) { }
@groovy.transform.Generated() public  java.util.Map<java.lang.String, java.lang.String> getHeaders() { return null; }
@groovy.transform.Generated() public  void setHeaders(java.util.Map<java.lang.String, java.lang.String> value) { }
public  java.lang.Object getContentBody() { return null; }
public  java.lang.String getMimeType() { return null; }
}
