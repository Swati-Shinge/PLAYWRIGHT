package io.restassured.internal;

public class RestAssuredResponseOptionsGroovyImpl
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
;
public static final java.lang.String BINARY = "binary";
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
@groovy.transform.Generated() public  java.lang.Object getResponseHeaders() { return null; }
@groovy.transform.Generated() public  void setResponseHeaders(java.lang.Object value) { }
@groovy.transform.Generated() public  void setCookies(io.restassured.http.Cookies value) { }
@groovy.transform.Generated() public  java.lang.Object getContent() { return null; }
@groovy.transform.Generated() public  void setContent(java.lang.Object value) { }
@groovy.transform.Generated() public  void setContentType(java.lang.Object value) { }
@groovy.transform.Generated() public  void setStatusLine(java.lang.Object value) { }
@groovy.transform.Generated() public  void setStatusCode(java.lang.Object value) { }
@groovy.transform.Generated() public  java.lang.Object getSessionIdName() { return null; }
@groovy.transform.Generated() public  void setSessionIdName(java.lang.Object value) { }
@groovy.transform.Generated() public  java.util.Map getFilterContextProperties() { return null; }
@groovy.transform.Generated() public  void setFilterContextProperties(java.util.Map value) { }
@groovy.transform.Generated() public  java.lang.Object getConnectionManager() { return null; }
@groovy.transform.Generated() public  void setConnectionManager(java.lang.Object value) { }
@groovy.transform.Generated() public  org.apache.http.protocol.HttpContext getApacheHttpContext() { return null; }
@groovy.transform.Generated() public  void setApacheHttpContext(org.apache.http.protocol.HttpContext value) { }
@groovy.transform.Generated() public  java.lang.String getDefaultContentType() { return null; }
@groovy.transform.Generated() public  void setDefaultContentType(java.lang.String value) { }
@groovy.transform.Generated() public  void setRpr(io.restassured.internal.ResponseParserRegistrar value) { }
@groovy.transform.Generated() public  io.restassured.config.DecoderConfig getDecoderConfig() { return null; }
@groovy.transform.Generated() public  void setDecoderConfig(io.restassured.config.DecoderConfig value) { }
@groovy.transform.Generated() public  boolean getHasExpectations() { return false; }
@groovy.transform.Generated() public  boolean isHasExpectations() { return false; }
@groovy.transform.Generated() public  void setHasExpectations(boolean value) { }
@groovy.transform.Generated() public  void setConfig(io.restassured.config.RestAssuredConfig value) { }
public  void parseResponse(io.restassured.internal.http.HttpResponseDecorator httpResponse, java.lang.Object content, java.lang.Object hasBodyAssertions, io.restassured.internal.ResponseParserRegistrar responseParserRegistrar) { }
public  java.lang.Object parseStatus(java.lang.Object httpResponse) { return null; }
public  java.lang.Object parseContentType(java.lang.Object httpResponse) { return null; }
public  java.lang.Object parseCookies() { return null; }
public  java.lang.Object parseHeaders(io.restassured.internal.http.HttpResponseDecorator httpResponse) { return null; }
public  java.lang.Object toString(groovy.lang.Writable node) { return null; }
public  java.lang.String print() { return null; }
public  java.lang.String prettyPrint(io.restassured.response.ResponseOptions responseOptions, io.restassured.response.ResponseBody responseBody) { return null; }
public  java.lang.Object peek(io.restassured.response.ResponseOptions responseOptions, io.restassured.response.ResponseBody responseBody) { return null; }
public  java.lang.Object prettyPeek(io.restassured.response.ResponseOptions responseOptions, io.restassured.response.ResponseBody responseBody) { return null; }
public  java.lang.String asString() { return null; }
public  java.lang.String asPrettyString(io.restassured.response.ResponseOptions responseOptions, io.restassured.response.ResponseBody responseBody) { return null; }
public  java.lang.String asString(boolean forcePlatformDefaultCharsetIfNoCharsetIsSpecifiedInResponse) { return null; }
public  boolean isInputStream() { return false; }
public  java.io.InputStream asInputStream() { return null; }
public  byte[] convertStringToByteArray(java.lang.Object string) { return null; }
public  byte[] asByteArray() { return null; }
public <T> T as(java.lang.reflect.Type cls, io.restassured.response.ResponseBodyData responseBodyData) { return null; }
public <T> T as(java.lang.reflect.Type cls, io.restassured.mapper.ObjectMapperType mapperType, io.restassured.response.ResponseBodyData responseBodyData) { return null; }
public <T> T as(java.lang.reflect.Type cls, io.restassured.mapper.ObjectMapper mapper) { return null; }
public <T> T as(io.restassured.common.mapper.TypeRef<T> typeRef, io.restassured.response.ResponseBodyData responseBodyData) { return null; }
public  java.lang.String findCharset() { return null; }
public  java.lang.String findCharset(boolean forcePlatformDefaultCharsetIfNoCharsetIsSpecifiedInResponse) { return null; }
public  io.restassured.http.Cookies detailedCookies() { return null; }
public  io.restassured.http.Cookies getDetailedCookies() { return null; }
public  io.restassured.http.Cookie detailedCookie(java.lang.String name) { return null; }
public  io.restassured.http.Cookie getDetailedCookie(java.lang.String name) { return null; }
public  io.restassured.http.Headers headers() { return null; }
public  io.restassured.http.Headers getHeaders() { return null; }
public  java.lang.String header(java.lang.String name) { return null; }
public  java.lang.String getHeader(java.lang.String name) { return null; }
public  java.util.Map<java.lang.String, java.lang.String> cookies() { return null; }
public  java.util.Map<java.lang.String, java.lang.String> getCookies() { return null; }
public  java.lang.String cookie(java.lang.String name) { return null; }
public  java.lang.String getCookie(java.lang.String name) { return null; }
public  java.lang.String contentType() { return null; }
public  io.restassured.internal.ResponseParserRegistrar getRpr() { return null; }
public  io.restassured.config.RestAssuredConfig getConfig() { return null; }
public  java.lang.String getContentType() { return null; }
public  java.lang.String statusLine() { return null; }
public  int statusCode() { return 0; }
public  java.lang.String getStatusLine() { return null; }
public  java.lang.String sessionId() { return null; }
public  java.lang.String getSessionId() { return null; }
public  int getStatusCode() { return 0; }
public  io.restassured.path.json.JsonPath jsonPath() { return null; }
public  io.restassured.path.json.JsonPath jsonPath(io.restassured.path.json.config.JsonPathConfig config) { return null; }
public  io.restassured.path.xml.XmlPath xmlPath() { return null; }
public  io.restassured.path.xml.XmlPath xmlPath(io.restassured.path.xml.config.XmlPathConfig config) { return null; }
public  io.restassured.path.xml.XmlPath xmlPath(io.restassured.path.xml.XmlPath.CompatibilityMode compatibilityMode) { return null; }
public  io.restassured.path.xml.XmlPath htmlPath() { return null; }
public <T> T path(java.lang.String path, java.lang.String... arguments) { return null; }
public  long time() { return 0; }
public  long timeIn(java.util.concurrent.TimeUnit timeUnit) { return 0; }
public  java.lang.Object charsetToString(java.lang.Object charset) { return null; }
}
