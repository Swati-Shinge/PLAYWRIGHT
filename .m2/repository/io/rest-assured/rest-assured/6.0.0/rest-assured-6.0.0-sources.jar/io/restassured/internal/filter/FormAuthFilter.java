package io.restassured.internal.filter;
import static io.restassured.config.CsrfConfig.CsrfPrioritization.FORM;
import static io.restassured.path.xml.XmlPath.CompatibilityMode.HTML;

public class FormAuthFilter
  extends java.lang.Object  implements
    io.restassured.spi.AuthFilter,    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
@groovy.transform.Generated() public  java.lang.Object getUserName() { return null; }
@groovy.transform.Generated() public  void setUserName(java.lang.Object value) { }
@groovy.transform.Generated() public  java.lang.Object getPassword() { return null; }
@groovy.transform.Generated() public  void setPassword(java.lang.Object value) { }
@groovy.transform.Generated() public  io.restassured.authentication.FormAuthConfig getFormAuthConfig() { return null; }
@groovy.transform.Generated() public  void setFormAuthConfig(io.restassured.authentication.FormAuthConfig value) { }
@groovy.transform.Generated() public  io.restassured.config.SessionConfig getSessionConfig() { return null; }
@groovy.transform.Generated() public  void setSessionConfig(io.restassured.config.SessionConfig value) { }
@groovy.transform.Generated() public  io.restassured.config.CsrfConfig getCsrfConfig() { return null; }
@groovy.transform.Generated() public  void setCsrfConfig(io.restassured.config.CsrfConfig value) { }
@java.lang.Override() public  io.restassured.response.Response filter(io.restassured.specification.FilterableRequestSpecification requestSpec, io.restassured.specification.FilterableResponseSpecification responseSpec, io.restassured.filter.FilterContext ctx) { return null; }
public static  void applySessionFilterFromOriginalRequestIfDefined(io.restassured.specification.FilterableRequestSpecification requestSpec, io.restassured.specification.RequestSpecification loginRequestSpec) { }
public static  java.lang.Object throwIfException(groovy.lang.Closure closure) { return null; }
}
