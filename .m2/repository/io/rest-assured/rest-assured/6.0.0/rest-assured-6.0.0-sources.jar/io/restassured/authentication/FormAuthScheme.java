package io.restassured.authentication;

public class FormAuthScheme
  extends java.lang.Object  implements
    io.restassured.authentication.AuthenticationScheme,    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
@groovy.transform.Generated() public  java.lang.Object getUserName() { return null; }
@groovy.transform.Generated() public  void setUserName(java.lang.Object value) { }
@groovy.transform.Generated() public  java.lang.Object getPassword() { return null; }
@groovy.transform.Generated() public  void setPassword(java.lang.Object value) { }
@groovy.transform.Generated() public  io.restassured.authentication.FormAuthConfig getConfig() { return null; }
@groovy.transform.Generated() public  void setConfig(io.restassured.authentication.FormAuthConfig value) { }
public  void authenticate(io.restassured.internal.http.HTTPBuilder httpBuilder) { }
}
