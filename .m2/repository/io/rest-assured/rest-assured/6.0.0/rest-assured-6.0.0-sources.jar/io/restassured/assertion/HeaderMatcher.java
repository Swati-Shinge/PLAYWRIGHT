package io.restassured.assertion;

public class HeaderMatcher
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
@groovy.transform.Generated() public  java.lang.Object getHeaderName() { return null; }
@groovy.transform.Generated() public  void setHeaderName(java.lang.Object value) { }
@groovy.transform.Generated() public  java.lang.Object getMappingFunction() { return null; }
@groovy.transform.Generated() public  void setMappingFunction(java.lang.Object value) { }
@groovy.transform.Generated() public  org.hamcrest.Matcher getMatcher() { return null; }
@groovy.transform.Generated() public  void setMatcher(org.hamcrest.Matcher value) { }
public  java.lang.Object validateHeader(java.lang.Object headers) { return null; }
}
