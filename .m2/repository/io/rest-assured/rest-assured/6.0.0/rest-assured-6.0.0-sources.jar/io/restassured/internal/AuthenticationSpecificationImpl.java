package io.restassured.internal;

public class AuthenticationSpecificationImpl
  extends java.lang.Object  implements
    io.restassured.specification.AuthenticationSpecification,    groovy.lang.GroovyObject {
;
public AuthenticationSpecificationImpl(io.restassured.specification.RequestSpecification requestSpecification) {}
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  io.restassured.specification.RequestSpecification basic(java.lang.String userName, java.lang.String password) { return null; }
public  io.restassured.specification.RequestSpecification ntlm(java.lang.String userName, java.lang.String password, java.lang.String workstation, java.lang.String domain) { return null; }
public  io.restassured.specification.RequestSpecification digest(java.lang.String userName, java.lang.String password) { return null; }
public  io.restassured.specification.RequestSpecification certificate(java.lang.String certURL, java.lang.String password) { return null; }
public  io.restassured.specification.RequestSpecification certificate(java.lang.String certURL, java.lang.String password, io.restassured.authentication.CertificateAuthSettings settings) { return null; }
public  io.restassured.specification.RequestSpecification oauth(java.lang.String consumerKey, java.lang.String consumerSecret, java.lang.String accessToken, java.lang.String secretToken) { return null; }
public  io.restassured.specification.RequestSpecification oauth(java.lang.String consumerKey, java.lang.String consumerSecret, java.lang.String accessToken, java.lang.String secretToken, io.restassured.authentication.OAuthSignature signature) { return null; }
public  io.restassured.specification.RequestSpecification oauth2(java.lang.String accessToken) { return null; }
public  io.restassured.specification.RequestSpecification oauth2(java.lang.String accessToken, io.restassured.authentication.OAuthSignature signature) { return null; }
public  io.restassured.specification.RequestSpecification none() { return null; }
public  io.restassured.specification.PreemptiveAuthSpec preemptive() { return null; }
public  io.restassured.specification.RequestSpecification form(java.lang.String userName, java.lang.String password) { return null; }
public  io.restassured.specification.RequestSpecification form(java.lang.String userName, java.lang.String password, io.restassured.authentication.FormAuthConfig config) { return null; }
}
