package io.restassured.internal.filter;
import static io.restassured.config.CsrfConfig.CsrfPrioritization.FORM;

public class CsrfFilter
  extends java.lang.Object  implements
    io.restassured.filter.Filter,    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
@groovy.transform.Generated() public  io.restassured.config.CsrfConfig getCsrfConfig() { return null; }
@groovy.transform.Generated() public  void setCsrfConfig(io.restassured.config.CsrfConfig value) { }
@java.lang.Override() public  io.restassured.response.Response filter(io.restassured.specification.FilterableRequestSpecification requestSpec, io.restassured.specification.FilterableResponseSpecification responseSpec, io.restassured.filter.FilterContext ctx) { return null; }
}
