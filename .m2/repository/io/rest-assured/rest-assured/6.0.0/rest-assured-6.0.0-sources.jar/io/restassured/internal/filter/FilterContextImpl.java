package io.restassured.internal.filter;

public class FilterContextImpl
  extends java.lang.Object  implements
    io.restassured.filter.FilterContext,    groovy.lang.GroovyObject {
;
public FilterContextImpl(java.lang.String requestUri, java.lang.String fullOriginalPath, java.lang.String fullSubstitutedPath, java.lang.String internalRequestUri, java.lang.String userDefinedPath, java.lang.Object[] unnamedPathParams, java.lang.String method, java.lang.Object assertionClosure, java.util.Iterator<io.restassured.filter.Filter> filters, java.util.Map<java.lang.String, java.lang.Object> properties) {}
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
@groovy.transform.Generated() public  java.lang.Object getAssertionClosure() { return null; }
@groovy.transform.Generated() public  void setAssertionClosure(java.lang.Object value) { }
@groovy.transform.Generated() public  java.util.Map<java.lang.String, java.lang.Object> getProperties() { return null; }
@groovy.transform.Generated() public  void setProperties(java.util.Map<java.lang.String, java.lang.Object> value) { }
public  io.restassured.response.Response next(io.restassured.specification.FilterableRequestSpecification request, io.restassured.specification.FilterableResponseSpecification response) { return null; }
@java.lang.SuppressWarnings(value="GroovyUnusedDeclaration") public  java.lang.String getInternalRequestURI() { return null; }
public  io.restassured.response.Response send(io.restassured.specification.RequestSender requestSender) { return null; }
public  void setValue(java.lang.String name, java.lang.Object value) { }
public  boolean hasValue(java.lang.String name) { return false; }
@java.lang.Override() public  boolean hasValue(java.lang.String name, java.lang.Object value) { return false; }
public  java.lang.Object getValue(java.lang.String name) { return null; }
}
