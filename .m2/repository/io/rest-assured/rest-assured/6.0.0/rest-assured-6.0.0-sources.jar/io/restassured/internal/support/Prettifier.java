package io.restassured.internal.support;

public class Prettifier
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.String getPrettifiedBodyIfPossible(io.restassured.specification.FilterableRequestSpecification request) { return null; }
public  java.lang.String getPrettifiedBodyIfPossible(io.restassured.response.ResponseOptions responseOptions, io.restassured.response.ResponseBody responseBody) { return null; }
public  java.lang.String prettify(java.lang.Object content, io.restassured.parsing.Parser parser) { return null; }
}
