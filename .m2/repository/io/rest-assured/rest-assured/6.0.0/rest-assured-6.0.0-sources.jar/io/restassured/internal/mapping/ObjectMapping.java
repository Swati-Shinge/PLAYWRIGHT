package io.restassured.internal.mapping;
import static io.restassured.http.ContentType.ANY;
import static io.restassured.common.mapper.resolver.ObjectMapperResolver.*;

public class ObjectMapping
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
public static <T> T deserialize(io.restassured.response.ResponseBodyData response, java.lang.reflect.Type cls, java.lang.String contentType, java.lang.String defaultContentType, java.lang.String charset, io.restassured.mapper.ObjectMapperType mapperType, io.restassured.config.ObjectMapperConfig objectMapperConfig) { return null; }
public static  java.lang.String serialize(java.lang.Object object, java.lang.String contentType, java.lang.String charset, io.restassured.mapper.ObjectMapperType mapperType, io.restassured.config.ObjectMapperConfig config, io.restassured.config.EncoderConfig encoderConfig) { return null; }
public static  java.lang.Object parseWithJackson1(io.restassured.mapper.ObjectMapperDeserializationContext ctx, io.restassured.path.json.mapper.factory.Jackson1ObjectMapperFactory factory) { return null; }
public static  java.lang.Object parseWithJackson2(io.restassured.mapper.ObjectMapperDeserializationContext ctx, io.restassured.path.json.mapper.factory.Jackson2ObjectMapperFactory factory) { return null; }
public static  java.lang.Object parseWithJackson3(io.restassured.mapper.ObjectMapperDeserializationContext ctx, io.restassured.path.json.mapper.factory.Jackson3ObjectMapperFactory factory) { return null; }
public static  java.lang.Object parseWithJohnzon(io.restassured.mapper.ObjectMapperDeserializationContext ctx, io.restassured.path.json.mapper.factory.JohnzonObjectMapperFactory factory) { return null; }
public static  java.lang.Object parseWithJsonb(io.restassured.mapper.ObjectMapperDeserializationContext ctx, io.restassured.path.json.mapper.factory.JsonbObjectMapperFactory factory) { return null; }
}
