package io.restassured.internal.support;
import static io.restassured.config.ParamConfig.UpdateStrategy.MERGE;

public class ParameterUpdater
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
;
public ParameterUpdater(io.restassured.internal.support.ParameterUpdater.Serializer serializer) {}
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  void updateParameters(io.restassured.config.ParamConfig.UpdateStrategy strategy, java.util.Map<java.lang.String, java.lang.Object> from, java.util.Map<java.lang.String, java.lang.Object> to) { }
public  void updateCollectionParameter(io.restassured.config.ParamConfig.UpdateStrategy strategy, java.util.Map<java.lang.String, java.lang.Object> to, java.lang.String key, java.util.Collection<java.lang.Object> values) { }
public  void updateZeroToManyParameters(io.restassured.config.ParamConfig.UpdateStrategy strategy, java.util.Map<java.lang.String, java.lang.Object> to, java.lang.String parameterName, java.lang.Object... parameterValues) { }
public  void updateStandardParameter(io.restassured.config.ParamConfig.UpdateStrategy strategy, java.util.Map<java.lang.String, java.lang.Object> to, java.lang.String key) { }
public  void updateStandardParameter(io.restassured.config.ParamConfig.UpdateStrategy strategy, java.util.Map<java.lang.String, java.lang.Object> to, java.lang.String key, java.lang.Object value) { }
public static interface Serializer
 {
 java.lang.String serializeIfNeeded(java.lang.Object value);
}
}
