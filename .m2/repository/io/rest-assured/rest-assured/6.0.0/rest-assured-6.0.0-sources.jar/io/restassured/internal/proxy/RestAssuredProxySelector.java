package io.restassured.internal.proxy;
import static java.net.Proxy.Type.HTTP;

public class RestAssuredProxySelector
  extends java.net.ProxySelector  implements
    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
@groovy.transform.Generated() public  java.net.ProxySelector getDelegatingProxySelector() { return null; }
@groovy.transform.Generated() public  void setDelegatingProxySelector(java.net.ProxySelector value) { }
@groovy.transform.Generated() public  io.restassured.specification.ProxySpecification getProxySpecification() { return null; }
@groovy.transform.Generated() public  void setProxySpecification(io.restassured.specification.ProxySpecification value) { }
public  java.util.List<java.net.Proxy> select(java.net.URI uri) { return null; }
public  void connectFailed(java.net.URI uri, java.net.SocketAddress sa, java.io.IOException ioe) { }
}
