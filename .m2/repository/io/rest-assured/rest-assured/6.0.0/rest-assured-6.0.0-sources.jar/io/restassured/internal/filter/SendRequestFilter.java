package io.restassured.internal.filter;

public class SendRequestFilter
  extends java.lang.Object  implements
    io.restassured.filter.Filter,    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
@java.lang.Override() public  io.restassured.response.Response filter(io.restassured.specification.FilterableRequestSpecification requestSpecification, io.restassured.specification.FilterableResponseSpecification responseSpecification, io.restassured.filter.FilterContext context) { return null; }
}
