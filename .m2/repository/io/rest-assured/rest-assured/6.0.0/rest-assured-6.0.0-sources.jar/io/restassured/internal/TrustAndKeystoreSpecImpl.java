package io.restassured.internal;
import static org.apache.http.conn.ssl.SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER;
import static org.apache.http.conn.ssl.SSLSocketFactory.BROWSER_COMPATIBLE_HOSTNAME_VERIFIER;

public class TrustAndKeystoreSpecImpl
  extends java.lang.Object  implements
    io.restassured.internal.TrustAndKeystoreSpec,    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
@groovy.transform.Generated() public  java.lang.Object getKeyStorePath() { return null; }
@groovy.transform.Generated() public  void setKeyStorePath(java.lang.Object value) { }
@groovy.transform.Generated() public  java.lang.String getKeyStorePassword() { return null; }
@groovy.transform.Generated() public  void setKeyStorePassword(java.lang.String value) { }
@groovy.transform.Generated() public  java.lang.String getKeyStoreType() { return null; }
@groovy.transform.Generated() public  void setKeyStoreType(java.lang.String value) { }
@groovy.transform.Generated() public  java.security.KeyStore getKeyStore() { return null; }
@groovy.transform.Generated() public  void setKeyStore(java.security.KeyStore value) { }
@groovy.transform.Generated() public  java.lang.Object getTrustStorePath() { return null; }
@groovy.transform.Generated() public  void setTrustStorePath(java.lang.Object value) { }
@groovy.transform.Generated() public  java.lang.String getTrustStorePassword() { return null; }
@groovy.transform.Generated() public  void setTrustStorePassword(java.lang.String value) { }
@groovy.transform.Generated() public  java.lang.String getTrustStoreType() { return null; }
@groovy.transform.Generated() public  void setTrustStoreType(java.lang.String value) { }
@groovy.transform.Generated() public  java.security.KeyStore getTrustStore() { return null; }
@groovy.transform.Generated() public  void setTrustStore(java.security.KeyStore value) { }
@groovy.transform.Generated() public  int getPort() { return 0; }
@groovy.transform.Generated() public  void setPort(int value) { }
@groovy.transform.Generated() public  org.apache.http.conn.ssl.SSLSocketFactory getFactory() { return null; }
@groovy.transform.Generated() public  void setFactory(org.apache.http.conn.ssl.SSLSocketFactory value) { }
@groovy.transform.Generated() public  org.apache.http.conn.ssl.X509HostnameVerifier getX509HostnameVerifier() { return null; }
@groovy.transform.Generated() public  void setX509HostnameVerifier(org.apache.http.conn.ssl.X509HostnameVerifier value) { }
public  void apply(io.restassured.internal.http.HTTPBuilder builder, int port) { }
public  java.security.KeyStore createStore(java.lang.Object keyStoreType, java.lang.Object keyStorePath, java.lang.Object keyStorePassword) { return null; }
}
