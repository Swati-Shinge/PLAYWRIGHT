package io.restassured.authentication;

public class BasicAuthScheme
  extends java.lang.Object  implements
    io.restassured.authentication.AuthenticationScheme,    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
@groovy.transform.Generated() public  java.lang.String getUserName() { return null; }
@groovy.transform.Generated() public  void setUserName(java.lang.String value) { }
@groovy.transform.Generated() public  java.lang.String getPassword() { return null; }
@groovy.transform.Generated() public  void setPassword(java.lang.String value) { }
@java.lang.Override() public  void authenticate(io.restassured.internal.http.HTTPBuilder httpBuilder) { }
}
