package io.restassured.internal;

public class LogSpecificationImpl
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.io.PrintStream getPrintStream(io.restassured.specification.RequestSpecification requestSpecification) { return null; }
public  boolean shouldUrlEncodeRequestUri(io.restassured.specification.RequestSpecification requestSpecification) { return false; }
public  boolean shouldPrettyPrint(io.restassured.specification.RequestSpecification requestSpecification) { return false; }
}
