package io.restassured.authentication;

public class CertAuthScheme
  extends java.lang.Object  implements
    io.restassured.authentication.AuthenticationScheme,    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
@groovy.transform.Generated() public  java.lang.Object getPathToKeyStore() { return null; }
@groovy.transform.Generated() public  void setPathToKeyStore(java.lang.Object value) { }
@groovy.transform.Generated() public  java.lang.String getKeyStorePassword() { return null; }
@groovy.transform.Generated() public  void setKeyStorePassword(java.lang.String value) { }
@groovy.transform.Generated() public  java.lang.String getKeystoreType() { return null; }
@groovy.transform.Generated() public  void setKeystoreType(java.lang.String value) { }
@groovy.transform.Generated() public  java.lang.Object getPathToTrustStore() { return null; }
@groovy.transform.Generated() public  void setPathToTrustStore(java.lang.Object value) { }
@groovy.transform.Generated() public  java.lang.String getTrustStorePassword() { return null; }
@groovy.transform.Generated() public  void setTrustStorePassword(java.lang.String value) { }
@groovy.transform.Generated() public  java.lang.String getTrustStoreType() { return null; }
@groovy.transform.Generated() public  void setTrustStoreType(java.lang.String value) { }
@groovy.transform.Generated() public  int getPort() { return 0; }
@groovy.transform.Generated() public  void setPort(int value) { }
@groovy.transform.Generated() public  java.security.KeyStore getTrustStore() { return null; }
@groovy.transform.Generated() public  void setTrustStore(java.security.KeyStore value) { }
@groovy.transform.Generated() public  java.security.KeyStore getKeyStore() { return null; }
@groovy.transform.Generated() public  void setKeyStore(java.security.KeyStore value) { }
@groovy.transform.Generated() public  org.apache.http.conn.ssl.X509HostnameVerifier getX509HostnameVerifier() { return null; }
@groovy.transform.Generated() public  void setX509HostnameVerifier(org.apache.http.conn.ssl.X509HostnameVerifier value) { }
@groovy.transform.Generated() public  org.apache.http.conn.ssl.SSLSocketFactory getSslSocketFactory() { return null; }
@groovy.transform.Generated() public  void setSslSocketFactory(org.apache.http.conn.ssl.SSLSocketFactory value) { }
@java.lang.Override() public  void authenticate(io.restassured.internal.http.HTTPBuilder httpBuilder) { }
}
