package io.restassured.internal;

public class SpecificationMerger
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
public static  void merge(io.restassured.internal.ResponseSpecificationImpl thisOne, io.restassured.internal.ResponseSpecificationImpl with) { }
public static  void merge(io.restassured.internal.RequestSpecificationImpl thisOne, io.restassured.internal.RequestSpecificationImpl with) { }
}
