package io.restassured.internal.mapping;

public class JohnzonMapper
  extends java.lang.Object  implements
    io.restassured.mapper.ObjectMapper,    groovy.lang.GroovyObject {
;
public JohnzonMapper(io.restassured.path.json.mapper.factory.JohnzonObjectMapperFactory factory) {}
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object deserialize(io.restassured.mapper.ObjectMapperDeserializationContext context) { return null; }
public  java.lang.Object serialize(io.restassured.mapper.ObjectMapperSerializationContext context) { return null; }
}
