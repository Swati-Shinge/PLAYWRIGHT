package io.restassured.internal;
import static io.restassured.parsing.Parser.*;

public class ContentParser
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object parse(io.restassured.response.Response response, io.restassured.internal.ResponseParserRegistrar rpr, io.restassured.config.RestAssuredConfig config, boolean parseAsString) { return null; }
}
