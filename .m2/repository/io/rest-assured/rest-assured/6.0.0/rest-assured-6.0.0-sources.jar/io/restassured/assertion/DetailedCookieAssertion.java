package io.restassured.assertion;

public class DetailedCookieAssertion
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
@groovy.transform.Generated() public  java.lang.String getCookieName() { return null; }
@groovy.transform.Generated() public  void setCookieName(java.lang.String value) { }
@groovy.transform.Generated() public  org.hamcrest.Matcher<? super io.restassured.http.Cookie> getMatcher() { return null; }
@groovy.transform.Generated() public  void setMatcher(org.hamcrest.Matcher<? super io.restassured.http.Cookie> value) { }
public  java.lang.Object validateCookies(java.util.List<java.lang.String> headerWithCookieList, io.restassured.http.Cookies responseCookies) { return null; }
}
