package io.restassured.internal.csrf;
import static io.restassured.config.CsrfConfig.CsrfPrioritization.FORM;
import static io.restassured.config.CsrfConfig.CsrfPrioritization.HEADER;

public class CsrfTokenFinder
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
public static  io.restassured.internal.csrf.CsrfData findInHtml(io.restassured.config.CsrfConfig csrfConfig, io.restassured.response.Response pageThatContainsCsrfToken) { return null; }
}
