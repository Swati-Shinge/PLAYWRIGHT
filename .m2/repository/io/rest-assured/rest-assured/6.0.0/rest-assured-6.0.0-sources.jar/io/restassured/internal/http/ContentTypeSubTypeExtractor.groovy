/*
 * Copyright 2019 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


package io.restassured.internal.http

import org.apache.commons.lang3.StringUtils

import static org.apache.commons.lang3.StringUtils.isBlank

class ContentTypeSubTypeExtractor {

  private static final String COMMA = ";"

  public static String getSubTypeValueFromContentType(String contentType, String subType) {
    def foundSubType = null
    if (isBlank(contentType)) {
      foundSubType = null;
    } else if (StringUtils.containsIgnoreCase(contentType, subType)) {
      contentType.split(COMMA).each {
        if (StringUtils.containsIgnoreCase(contentType, subType)) {
          def equalsSign = it.split("=")
          if (equalsSign != null && equalsSign.length == 2 && equalsSign[0].trim().equalsIgnoreCase(subType)) {
            foundSubType = equalsSign[1]?.trim();
            //remove quotations if present
            foundSubType = StringUtils.removeStart(foundSubType, "\"")
            foundSubType = StringUtils.removeEnd(foundSubType, "\"")
          }
        }
      }
    }
    foundSubType;
  }
}
