package io.restassured.internal;

public class RequestLogSpecificationImpl
  extends io.restassured.internal.LogSpecificationImpl  implements
    io.restassured.specification.RequestLogSpecification {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
@groovy.transform.Generated() public  io.restassured.specification.RequestSpecification getRequestSpecification() { return null; }
@groovy.transform.Generated() public  void setRequestSpecification(io.restassured.specification.RequestSpecification value) { }
@groovy.transform.Generated() public  io.restassured.internal.log.LogRepository getLogRepository() { return null; }
@groovy.transform.Generated() public  void setLogRepository(io.restassured.internal.log.LogRepository value) { }
@groovy.transform.Generated() public  java.util.Set<java.lang.String> getBlacklistedHeaders() { return null; }
@groovy.transform.Generated() public  void setBlacklistedHeaders(java.util.Set<java.lang.String> value) { }
public  io.restassured.specification.RequestSpecification params() { return null; }
public  io.restassured.specification.RequestSpecification parameters() { return null; }
public  io.restassured.specification.RequestSpecification uri() { return null; }
public  io.restassured.specification.RequestSpecification method() { return null; }
public  io.restassured.specification.RequestSpecification body() { return null; }
public  io.restassured.specification.RequestSpecification body(boolean shouldPrettyPrint) { return null; }
public  io.restassured.specification.RequestSpecification all(boolean shouldPrettyPrint) { return null; }
public  io.restassured.specification.RequestSpecification everything(boolean shouldPrettyPrint) { return null; }
public  io.restassured.specification.RequestSpecification all() { return null; }
public  io.restassured.specification.RequestSpecification everything() { return null; }
public  io.restassured.specification.RequestSpecification headers() { return null; }
public  io.restassured.specification.RequestSpecification cookies() { return null; }
public  io.restassured.specification.RequestSpecification ifValidationFails() { return null; }
public  io.restassured.specification.RequestSpecification ifValidationFails(io.restassured.filter.log.LogDetail logDetail) { return null; }
public  io.restassured.specification.RequestSpecification ifValidationFails(io.restassured.filter.log.LogDetail logDetail, boolean shouldPrettyPrint) { return null; }
}
