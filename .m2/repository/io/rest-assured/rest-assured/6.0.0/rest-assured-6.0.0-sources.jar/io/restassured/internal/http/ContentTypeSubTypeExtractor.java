package io.restassured.internal.http;

public class ContentTypeSubTypeExtractor
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
public static  java.lang.String getSubTypeValueFromContentType(java.lang.String contentType, java.lang.String subType) { return null; }
}
