package io.restassured.internal;
import static io.restassured.http.ContentType.ANY;

public class ResponseSpecificationImpl
  extends java.lang.Object  implements
    io.restassured.specification.FilterableResponseSpecification,    groovy.lang.GroovyObject {
;
public ResponseSpecificationImpl(java.lang.String bodyRootPath, io.restassured.specification.ResponseSpecification defaultSpec, io.restassured.internal.ResponseParserRegistrar rpr, io.restassured.config.RestAssuredConfig config, io.restassured.internal.log.LogRepository logRepository) {
super ();
}
public ResponseSpecificationImpl(java.lang.String bodyRootPath, io.restassured.specification.ResponseSpecification defaultSpec, io.restassured.internal.ResponseParserRegistrar rpr, io.restassured.config.RestAssuredConfig config, io.restassured.response.Response response, io.restassured.internal.log.LogRepository logRepository) {}
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
@groovy.transform.Generated() public  io.restassured.internal.ResponseParserRegistrar getRpr() { return null; }
@groovy.transform.Generated() public  void setRpr(io.restassured.internal.ResponseParserRegistrar value) { }
@groovy.transform.Generated() public  io.restassured.config.RestAssuredConfig getConfig() { return null; }
@groovy.transform.Generated() public  void setConfig(io.restassured.config.RestAssuredConfig value) { }
@groovy.transform.Generated() public  io.restassured.internal.log.LogRepository getLogRepository() { return null; }
@groovy.transform.Generated() public  void setLogRepository(io.restassured.internal.log.LogRepository value) { }
public  io.restassured.specification.ResponseSpecification body(java.util.List<io.restassured.specification.Argument> arguments, org.hamcrest.Matcher matcher, java.lang.Object... additionalKeyMatcherPairs) { return null; }
public  io.restassured.response.Response validate(io.restassured.response.Response response) { return null; }
public  io.restassured.specification.ResponseSpecification body(org.hamcrest.Matcher matcher, org.hamcrest.Matcher... additionalMatchers) { return null; }
public  io.restassured.specification.ResponseSpecification body(java.lang.String key, org.hamcrest.Matcher matcher, java.lang.Object... additionalKeyMatcherPairs) { return null; }
public  io.restassured.specification.ResponseSpecification time(org.hamcrest.Matcher<java.lang.Long> matcher) { return null; }
public  io.restassured.specification.ResponseSpecification time(org.hamcrest.Matcher<java.lang.Long> matcher, java.util.concurrent.TimeUnit timeUnit) { return null; }
public  io.restassured.specification.ResponseSpecification statusCode(org.hamcrest.Matcher<? super java.lang.Integer> expectedStatusCode) { return null; }
public  io.restassured.specification.ResponseSpecification statusCode(int expectedStatusCode) { return null; }
public  io.restassured.specification.ResponseSpecification statusLine(org.hamcrest.Matcher<? super java.lang.String> expectedStatusLine) { return null; }
public  io.restassured.specification.ResponseSpecification headers(java.util.Map expectedHeaders) { return null; }
public  io.restassured.specification.ResponseSpecification headers(java.lang.String firstExpectedHeaderName, java.lang.Object firstExpectedHeaderValue, java.lang.Object... expectedHeaders) { return null; }
@java.lang.Override() public  io.restassured.specification.ResponseSpecification header(java.lang.String headerName, java.util.function.Function mappingFunction, org.hamcrest.Matcher expectedValueMatcher) { return null; }
public  io.restassured.specification.ResponseSpecification header(java.lang.String headerName, org.hamcrest.Matcher expectedValueMatcher) { return null; }
public  io.restassured.specification.ResponseSpecification header(java.lang.String headerName, java.lang.String expectedValue) { return null; }
public  io.restassured.specification.ResponseSpecification cookies(java.util.Map expectedCookies) { return null; }
public  io.restassured.specification.ResponseSpecification cookies(java.lang.String firstExpectedCookieName, java.lang.Object firstExpectedCookieValue, java.lang.Object... expectedCookieNameValuePairs) { return null; }
public  io.restassured.specification.ResponseSpecification cookie(java.lang.String cookieName, org.hamcrest.Matcher expectedValueMatcher) { return null; }
public  io.restassured.specification.ResponseSpecification cookie(java.lang.String cookieName, io.restassured.matcher.DetailedCookieMatcher detailedCookieMatcher) { return null; }
public  io.restassured.specification.ResponseSpecification cookie(java.lang.String cookieName) { return null; }
public  io.restassured.specification.ResponseSpecification cookie(java.lang.String cookieName, java.lang.Object expectedValue) { return null; }
public  io.restassured.specification.ResponseSpecification spec(io.restassured.specification.ResponseSpecification responseSpecificationToMerge) { return null; }
public  io.restassured.specification.ResponseSpecification specification(io.restassured.specification.ResponseSpecification responseSpecificationToMerge) { return null; }
public  io.restassured.specification.ResponseSpecification statusLine(java.lang.String expectedStatusLine) { return null; }
public  io.restassured.specification.ResponseSpecification body(java.lang.String key, java.util.List<io.restassured.specification.Argument> arguments, org.hamcrest.Matcher matcher, java.lang.Object... additionalKeyMatcherPairs) { return null; }
public  io.restassured.specification.ResponseLogSpecification log() { return null; }
public  io.restassured.internal.ResponseSpecificationImpl logDetail(io.restassured.filter.log.LogDetail logDetail) { return null; }
public  io.restassured.specification.ResponseSpecification onFailMessage(java.lang.String message) { return null; }
public  io.restassured.filter.log.LogDetail getLogDetail() { return null; }
public  io.restassured.specification.RequestSender when() { return null; }
public  io.restassured.specification.ResponseSpecification response() { return null; }
public  io.restassured.specification.RequestSpecification given() { return null; }
public  io.restassured.specification.ResponseSpecification that() { return null; }
public  io.restassured.specification.RequestSpecification request() { return null; }
public  io.restassured.specification.ResponseSpecification parser(java.lang.String contentType, io.restassured.parsing.Parser parser) { return null; }
public  io.restassured.specification.ResponseSpecification and() { return null; }
public  io.restassured.specification.RequestSpecification with() { return null; }
public  io.restassured.specification.ResponseSpecification then() { return null; }
public  io.restassured.specification.ResponseSpecification expect() { return null; }
public  io.restassured.specification.ResponseSpecification rootPath(java.lang.String rootPath) { return null; }
public  io.restassured.specification.ResponseSpecification noRootPath() { return null; }
public  io.restassured.specification.ResponseSpecification appendRootPath(java.lang.String pathToAppend) { return null; }
public  io.restassured.specification.ResponseSpecification appendRootPath(java.lang.String pathToAppend, java.util.List<io.restassured.specification.Argument> arguments) { return null; }
public  io.restassured.specification.ResponseSpecification detachRootPath(java.lang.String pathToDetach) { return null; }
public  io.restassured.specification.ResponseSpecification rootPath(java.lang.String rootPath, java.util.List<io.restassured.specification.Argument> arguments) { return null; }
public  io.restassured.specification.ResponseSpecification root(java.lang.String rootPath, java.util.List<io.restassured.specification.Argument> arguments) { return null; }
public  boolean hasBodyAssertionsDefined() { return false; }
public  boolean hasAssertionsDefined() { return false; }
public  io.restassured.specification.ResponseSpecification defaultParser(io.restassured.parsing.Parser parser) { return null; }
public  io.restassured.specification.ResponseSpecification contentType(io.restassured.http.ContentType contentType) { return null; }
public  io.restassured.specification.ResponseSpecification contentType(java.lang.String contentType) { return null; }
public  io.restassured.specification.ResponseSpecification contentType(org.hamcrest.Matcher<? super java.lang.String> contentType) { return null; }
public  org.hamcrest.Matcher<java.lang.Integer> getStatusCode() { return null; }
public  org.hamcrest.Matcher<java.lang.String> getStatusLine() { return null; }
public  boolean hasHeaderAssertions() { return false; }
public  boolean hasCookieAssertions() { return false; }
public  java.lang.String getResponseContentType() { return null; }
public  java.lang.String getRootPath() { return null; }
public  void throwIllegalStateExceptionIfRootPathIsNotDefined(java.lang.String description) { }
public  java.lang.Object forceDisableEagerAssert() { return null; }
public  java.lang.Object forceValidateResponse() { return null; }
public class HamcrestAssertionClosure
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
;
public HamcrestAssertionClosure(io.restassured.specification.ResponseSpecification responseSpecification) {}
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object call(java.lang.Object response, java.lang.Object content) { return null; }
public  java.lang.Object call(java.lang.Object response) { return null; }
public  java.lang.Object getResponseContentType() { return null; }
public  java.lang.Object getClosure() { return null; }
public  java.lang.Object validate(io.restassured.response.Response response) { return null; }
}
}
