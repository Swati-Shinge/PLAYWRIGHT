package io.restassured.internal.mapping;

public class JaxbMapper
  extends java.lang.Object  implements
    io.restassured.mapper.ObjectMapper,    groovy.lang.GroovyObject {
;
public JaxbMapper(io.restassured.path.xml.mapper.factory.JAXBObjectMapperFactory factory) {}
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object deserialize(io.restassured.mapper.ObjectMapperDeserializationContext context) { return null; }
@java.lang.SuppressWarnings(value="UnnecessaryQualifiedReference") public  java.lang.Object serialize(io.restassured.mapper.ObjectMapperSerializationContext context) { return null; }
}
