package io.restassured.internal;

public class PreemptiveAuthSpecImpl
  extends java.lang.Object  implements
    io.restassured.specification.PreemptiveAuthSpec,    groovy.lang.GroovyObject {
;
public PreemptiveAuthSpecImpl(io.restassured.specification.RequestSpecification requestBuilder) {}
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  io.restassured.specification.RequestSpecification basic(java.lang.String username, java.lang.String password) { return null; }
public  io.restassured.specification.RequestSpecification oauth2(java.lang.String accessToken) { return null; }
}
