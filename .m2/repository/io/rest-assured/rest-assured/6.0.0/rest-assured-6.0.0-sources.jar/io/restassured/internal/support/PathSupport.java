package io.restassured.internal.support;

public class PathSupport
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
public static  java.lang.String mergeAndRemoveDoubleSlash(java.lang.String thisOne, java.lang.String otherOne) { return null; }
public static  boolean isFullyQualified(java.lang.String targetUri) { return false; }
public static  java.lang.String getPath(java.lang.String targetUri) { return null; }
}
