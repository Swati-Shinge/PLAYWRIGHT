package io.restassured.internal.multipart;

public class RestAssuredMultiPartEntity
  extends java.lang.Object  implements
    org.apache.http.HttpEntity,    groovy.lang.GroovyObject {
;
public RestAssuredMultiPartEntity(java.lang.String subType, java.lang.String charset, org.apache.http.entity.mime.HttpMultipartMode mode, java.lang.String boundary) {}
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  void addPart(org.apache.http.entity.mime.FormBodyPart bodyPart) { }
public  void addPart(java.lang.String name, org.apache.http.entity.mime.content.ContentBody contentBody) { }
public  boolean isRepeatable() { return false; }
public  boolean isChunked() { return false; }
public  boolean isStreaming() { return false; }
public  long getContentLength() { return 0; }
public  org.apache.http.Header getContentType() { return null; }
public  org.apache.http.Header getContentEncoding() { return null; }
public  void consumeContent()throws java.io.IOException, java.lang.UnsupportedOperationException { }
public  java.io.InputStream getContent()throws java.io.IOException, java.lang.UnsupportedOperationException { return null; }
public  void writeTo(java.io.OutputStream outstream)throws java.io.IOException { }
}
