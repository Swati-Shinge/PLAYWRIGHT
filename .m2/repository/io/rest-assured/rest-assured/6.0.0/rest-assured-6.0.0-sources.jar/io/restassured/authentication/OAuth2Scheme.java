package io.restassured.authentication;

public class OAuth2Scheme
  extends java.lang.Object  implements
    io.restassured.authentication.AuthenticationScheme,    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
@groovy.transform.Generated() public  java.lang.String getAccessToken() { return null; }
@groovy.transform.Generated() public  void setAccessToken(java.lang.String value) { }
@groovy.transform.Generated() public  io.restassured.authentication.OAuthSignature getSignature() { return null; }
@groovy.transform.Generated() public  void setSignature(io.restassured.authentication.OAuthSignature value) { }
@java.lang.Override() public  void authenticate(io.restassured.internal.http.HTTPBuilder httpBuilder) { }
}
