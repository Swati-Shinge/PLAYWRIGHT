package io.restassured.internal.mapping;

public class ObjectMapperDeserializationContextImpl
  extends io.restassured.internal.common.ObjectDeserializationContextImpl  implements
    io.restassured.mapper.ObjectMapperDeserializationContext,    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
@groovy.transform.Generated() public  void setContentType(java.lang.Object value) { }
@java.lang.Override() public  java.lang.String getContentType() { return null; }
}
