package io.restassured.internal;

public class LogRequestAndResponseOnFailListener
  extends java.lang.Object  implements
    io.restassured.listener.ResponseValidationFailureListener,    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
@java.lang.Override() public  void onFailure(io.restassured.specification.RequestSpecification requestSpecification, io.restassured.specification.ResponseSpecification responseSpecification, io.restassured.response.Response response) { }
}
