package io.restassured.assertion;

public class ResponseTimeMatcher
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
@groovy.transform.Generated() public  org.hamcrest.Matcher<java.lang.Long> getMatcher() { return null; }
@groovy.transform.Generated() public  void setMatcher(org.hamcrest.Matcher<java.lang.Long> value) { }
@groovy.transform.Generated() public  java.util.concurrent.TimeUnit getTimeUnit() { return null; }
@groovy.transform.Generated() public  void setTimeUnit(java.util.concurrent.TimeUnit value) { }
public  java.lang.Object validate(io.restassured.response.Response response) { return null; }
}
