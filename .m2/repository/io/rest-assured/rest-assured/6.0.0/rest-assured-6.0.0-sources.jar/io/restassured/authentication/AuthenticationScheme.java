package io.restassured.authentication;

public interface AuthenticationScheme
 {
 void authenticate(io.restassured.internal.http.HTTPBuilder httpBuilder);
}
