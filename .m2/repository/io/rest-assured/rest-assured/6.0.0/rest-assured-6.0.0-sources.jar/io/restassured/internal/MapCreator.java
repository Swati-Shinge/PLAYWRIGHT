package io.restassured.internal;

public class MapCreator
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
public static  java.util.Map<java.lang.String, java.lang.Object> createMapFromParams(io.restassured.internal.MapCreator.CollisionStrategy collisionStrategy, java.lang.String firstParam, java.lang.Object firstValue, java.lang.Object... parameters) { return null; }
public static  java.util.Map<java.lang.String, java.lang.Object> createMapFromParams(io.restassured.internal.MapCreator.CollisionStrategy collisionStrategy, java.lang.String firstParam, java.lang.Object... parameters) { return null; }
public static  java.util.Map<java.lang.String, java.lang.Object> createMapFromObjects(io.restassured.internal.MapCreator.CollisionStrategy collisionStrategy, java.lang.Object... parameters) { return null; }
public static enum CollisionStrategy
  implements
    groovy.lang.GroovyObject {
MERGE, OVERWRITE;
public static final io.restassured.internal.MapCreator.CollisionStrategy MIN_VALUE = null;
public static final io.restassured.internal.MapCreator.CollisionStrategy MAX_VALUE = null;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
@groovy.transform.Generated() public  io.restassured.internal.MapCreator.CollisionStrategy next() { return null; }
@groovy.transform.Generated() public  io.restassured.internal.MapCreator.CollisionStrategy previous() { return null; }
@groovy.transform.Generated() public static final  io.restassured.internal.MapCreator.CollisionStrategy $INIT(java.lang.Object... para) { return null; }
}
@groovy.transform.Canonical() public static class ArgsAndValue
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
@groovy.transform.Generated() public  java.util.List<io.restassured.specification.Argument> getArgs() { return null; }
@groovy.transform.Generated() public  void setArgs(java.util.List<io.restassured.specification.Argument> value) { }
@groovy.transform.Generated() public  java.lang.Object getValue() { return null; }
@groovy.transform.Generated() public  void setValue(java.lang.Object value) { }
}
}
