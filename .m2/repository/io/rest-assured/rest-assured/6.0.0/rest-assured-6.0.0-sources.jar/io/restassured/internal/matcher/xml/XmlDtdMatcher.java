package io.restassured.internal.matcher.xml;

public class XmlDtdMatcher
  extends org.hamcrest.BaseMatcher<java.lang.String>  implements
    groovy.lang.GroovyObject {
;
private XmlDtdMatcher(java.lang.Object dtd) {}
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
@groovy.transform.Generated() public  java.lang.Object getDtd() { return null; }
@groovy.transform.Generated() public  void setDtd(java.lang.Object value) { }
public static  org.hamcrest.Matcher<java.lang.String> matchesDtd(java.lang.String dtd) { return null; }
public static  org.hamcrest.Matcher<java.lang.String> matchesDtd(java.io.InputStream dtd) { return null; }
public static  org.hamcrest.Matcher<java.lang.String> matchesDtd(java.io.File dtd) { return null; }
public static  org.hamcrest.Matcher<java.lang.String> matchesDtd(java.net.URL url) { return null; }
@java.lang.Override() public  boolean matches(java.lang.Object item) { return false; }
@java.lang.Override() public  void describeTo(org.hamcrest.Description description) { }
public static  org.hamcrest.Matcher<java.lang.String> matchesDtdInClasspath(java.lang.String path) { return null; }
private static class ExceptionThrowingErrorHandler
  extends java.lang.Object  implements
    org.xml.sax.ErrorHandler,    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
@java.lang.Override() public  void warning(org.xml.sax.SAXParseException exception) { }
@java.lang.Override() public  void error(org.xml.sax.SAXParseException exception) { }
@java.lang.Override() public  void fatalError(org.xml.sax.SAXParseException exception) { }
}
}
