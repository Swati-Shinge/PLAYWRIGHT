package io.restassured.internal;
import static org.apache.http.client.params.ClientPNames.*;

public class RedirectSpecificationImpl
  extends java.lang.Object  implements
    io.restassured.specification.RedirectSpecification,    groovy.lang.GroovyObject {
;
public RedirectSpecificationImpl(io.restassured.specification.RequestSpecification requestSpecification, java.util.Map httpClientParams) {}
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  io.restassured.specification.RequestSpecification max(int maxNumberOfRedirect) { return null; }
public  io.restassured.specification.RequestSpecification follow(boolean followRedirects) { return null; }
public  io.restassured.specification.RequestSpecification allowCircular(boolean allowCircularRedirects) { return null; }
public  io.restassured.specification.RequestSpecification rejectRelative(boolean rejectRelativeRedirects) { return null; }
}
