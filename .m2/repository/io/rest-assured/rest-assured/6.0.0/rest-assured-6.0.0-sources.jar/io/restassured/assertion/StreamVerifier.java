package io.restassured.assertion;

public class StreamVerifier
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
public static  java.lang.Object newAssertion(io.restassured.response.Response response, java.lang.Object key, io.restassured.internal.ResponseParserRegistrar rpr) { return null; }
public static  java.lang.Object createAssertionForCustomParser(io.restassured.internal.ResponseParserRegistrar rpr, java.lang.String contentType, java.lang.Object key) { return null; }
}
