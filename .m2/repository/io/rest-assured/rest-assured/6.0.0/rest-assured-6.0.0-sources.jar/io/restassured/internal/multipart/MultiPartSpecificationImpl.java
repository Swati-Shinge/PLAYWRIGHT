package io.restassured.internal.multipart;

public class MultiPartSpecificationImpl
  extends java.lang.Object  implements
    io.restassured.specification.MultiPartSpecification,    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
@groovy.transform.Generated() public  void setContent(java.lang.Object value) { }
@groovy.transform.Generated() public  void setControlName(java.lang.String value) { }
@groovy.transform.Generated() public  void setMimeType(java.lang.String value) { }
@groovy.transform.Generated() public  void setCharset(java.lang.String value) { }
@groovy.transform.Generated() public  boolean getControlNameSpecifiedExplicitly() { return false; }
@groovy.transform.Generated() public  boolean isControlNameSpecifiedExplicitly() { return false; }
@groovy.transform.Generated() public  void setControlNameSpecifiedExplicitly(boolean value) { }
@groovy.transform.Generated() public  boolean getFileNameSpecifiedExplicitly() { return false; }
@groovy.transform.Generated() public  boolean isFileNameSpecifiedExplicitly() { return false; }
@groovy.transform.Generated() public  void setFileNameSpecifiedExplicitly(boolean value) { }
@groovy.transform.Generated() public  void setHeaders(java.util.Map<java.lang.String, java.lang.String> value) { }
public  java.lang.Object getContent() { return null; }
public  java.lang.String getControlName() { return null; }
public  java.lang.String getMimeType() { return null; }
public  java.lang.String getCharset() { return null; }
public  java.lang.String getFileName() { return null; }
public  java.util.Map<java.lang.String, java.lang.String> getHeaders() { return null; }
public  boolean hasFileName() { return false; }
public  void setFileName(java.lang.String fileName) { }
public  java.lang.String toString() { return null; }
}
