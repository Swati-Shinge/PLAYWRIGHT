package io.restassured.internal;

public class RestAssuredHttpBuilderGroovyHelper
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
public static  java.util.Collection<java.lang.String> flattenToString(java.util.Collection collection) { return null; }
public static  groovy.lang.Closure createClosureThatCalls(java.lang.Object assertionClosure) { return null; }
}
