package io.restassured.internal.matcher.xml;

public class XmlXsdMatcher
  extends org.hamcrest.BaseMatcher<java.lang.String>  implements
    groovy.lang.GroovyObject {
;
private XmlXsdMatcher(java.lang.Object xsd) {}
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
@groovy.transform.Generated() public  java.lang.Object getXsd() { return null; }
@groovy.transform.Generated() public  void setXsd(java.lang.Object value) { }
@groovy.transform.Generated() public  java.lang.Object getResourceResolver() { return null; }
@groovy.transform.Generated() public  void setResourceResolver(java.lang.Object value) { }
public  io.restassured.internal.matcher.xml.XmlXsdMatcher using(org.w3c.dom.ls.LSResourceResolver resourceResolver) { return null; }
public  io.restassured.internal.matcher.xml.XmlXsdMatcher with(org.w3c.dom.ls.LSResourceResolver resourceResolver) { return null; }
public static  io.restassured.internal.matcher.xml.XmlXsdMatcher matchesXsd(java.lang.String xsd) { return null; }
public static  io.restassured.internal.matcher.xml.XmlXsdMatcher matchesXsd(java.io.InputStream xsd) { return null; }
public static  io.restassured.internal.matcher.xml.XmlXsdMatcher matchesXsd(java.io.Reader xsd) { return null; }
public static  io.restassured.internal.matcher.xml.XmlXsdMatcher matchesXsd(java.io.File xsd) { return null; }
public static  io.restassured.internal.matcher.xml.XmlXsdMatcher matchesXsd(java.net.URL url) { return null; }
@java.lang.Override() public  boolean matches(java.lang.Object item) { return false; }
@java.lang.Override() public  void describeTo(org.hamcrest.Description description) { }
public static  io.restassured.internal.matcher.xml.XmlXsdMatcher matchesXsdInClasspath(java.lang.String path) { return null; }
}
