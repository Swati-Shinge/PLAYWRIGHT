package io.restassured.internal.mapping;

public class Jackson1Mapper
  extends java.lang.Object  implements
    io.restassured.mapper.ObjectMapper,    groovy.lang.GroovyObject {
;
public Jackson1Mapper(io.restassured.path.json.mapper.factory.Jackson1ObjectMapperFactory factory) {}
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.String serialize(io.restassured.mapper.ObjectMapperSerializationContext context) { return null; }
public  java.lang.Object deserialize(io.restassured.mapper.ObjectMapperDeserializationContext context) { return null; }
}
