package io.restassured.internal.mapping;

public class ObjectMapperSerializationContextImpl
  extends java.lang.Object  implements
    io.restassured.mapper.ObjectMapperSerializationContext,    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
@groovy.transform.Generated() public  java.lang.Object getObject() { return null; }
@groovy.transform.Generated() public  void setObject(java.lang.Object value) { }
@groovy.transform.Generated() public  void setContentType(java.lang.Object value) { }
@groovy.transform.Generated() public  void setCharset(java.lang.Object value) { }
@java.lang.Override() public  java.lang.Object getObjectToSerialize() { return null; }
@java.lang.Override() public  java.lang.Object getObjectToSerializeAs(java.lang.Class expectedType) { return null; }
@java.lang.Override() public  java.lang.String getContentType() { return null; }
@java.lang.Override() public  java.lang.String getCharset() { return null; }
}
