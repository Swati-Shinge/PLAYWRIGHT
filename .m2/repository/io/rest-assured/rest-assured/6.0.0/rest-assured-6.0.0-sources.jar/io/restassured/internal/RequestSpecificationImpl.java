package io.restassured.internal;
import static io.restassured.config.ParamConfig.UpdateStrategy.REPLACE;
import static io.restassured.http.ContentType.*;
import static io.restassured.http.Method.*;
import static org.apache.commons.lang3.StringUtils.*;
import static org.apache.http.client.params.ClientPNames.*;

public class RequestSpecificationImpl
  extends java.lang.Object  implements
    io.restassured.specification.FilterableRequestSpecification,    groovy.lang.GroovyInterceptable {
;
public RequestSpecificationImpl(java.lang.String baseURI, int requestPort, java.lang.String basePath, io.restassured.authentication.AuthenticationScheme defaultAuthScheme, java.util.List<io.restassured.filter.Filter> filters, io.restassured.specification.RequestSpecification defaultSpec, boolean urlEncode, io.restassured.config.RestAssuredConfig restAssuredConfig, io.restassured.internal.log.LogRepository logRepository, io.restassured.specification.ProxySpecification proxySpecification, boolean allowContentType, boolean addCsrfFilter) {}
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
@groovy.transform.Generated() public  io.restassured.authentication.AuthenticationScheme getAuthenticationScheme() { return null; }
@groovy.transform.Generated() public  void setAuthenticationScheme(io.restassured.authentication.AuthenticationScheme value) { }
public  io.restassured.specification.RequestSpecification when() { return null; }
public  io.restassured.specification.RequestSpecification given() { return null; }
public  io.restassured.specification.RequestSpecification that() { return null; }
public  io.restassured.specification.ResponseSpecification response() { return null; }
public  io.restassured.response.Response get(java.lang.String path, java.lang.Object... pathParams) { return null; }
public  io.restassured.response.Response post(java.lang.String path, java.lang.Object... pathParams) { return null; }
public  io.restassured.response.Response put(java.lang.String path, java.lang.Object... pathParams) { return null; }
public  io.restassured.response.Response delete(java.lang.String path, java.lang.Object... pathParams) { return null; }
public  io.restassured.response.Response head(java.lang.String path, java.lang.Object... pathParams) { return null; }
public  io.restassured.response.Response patch(java.lang.String path, java.lang.Object... pathParams) { return null; }
public  io.restassured.response.Response options(java.lang.String path, java.lang.Object... pathParams) { return null; }
public  io.restassured.response.Response get(java.net.URI uri) { return null; }
public  io.restassured.response.Response post(java.net.URI uri) { return null; }
public  io.restassured.response.Response put(java.net.URI uri) { return null; }
public  io.restassured.response.Response delete(java.net.URI uri) { return null; }
public  io.restassured.response.Response head(java.net.URI uri) { return null; }
public  io.restassured.response.Response patch(java.net.URI uri) { return null; }
public  io.restassured.response.Response options(java.net.URI uri) { return null; }
public  io.restassured.response.Response get(java.net.URL url) { return null; }
public  io.restassured.response.Response post(java.net.URL url) { return null; }
public  io.restassured.response.Response put(java.net.URL url) { return null; }
public  io.restassured.response.Response delete(java.net.URL url) { return null; }
public  io.restassured.response.Response head(java.net.URL url) { return null; }
public  io.restassured.response.Response patch(java.net.URL url) { return null; }
public  io.restassured.response.Response options(java.net.URL url) { return null; }
public  io.restassured.response.Response get() { return null; }
public  io.restassured.response.Response post() { return null; }
public  io.restassured.response.Response put() { return null; }
public  io.restassured.response.Response delete() { return null; }
public  io.restassured.response.Response head() { return null; }
public  io.restassured.response.Response patch() { return null; }
public  io.restassured.response.Response options() { return null; }
public  io.restassured.response.Response request(io.restassured.http.Method method) { return null; }
public  io.restassured.response.Response request(java.lang.String method) { return null; }
public  io.restassured.response.Response request(io.restassured.http.Method method, java.lang.String path, java.lang.Object... pathParams) { return null; }
public  io.restassured.response.Response request(java.lang.String method, java.lang.String path, java.lang.Object... pathParams) { return null; }
public  io.restassured.response.Response request(io.restassured.http.Method method, java.net.URI uri) { return null; }
public  io.restassured.response.Response request(io.restassured.http.Method method, java.net.URL url) { return null; }
public  io.restassured.response.Response request(java.lang.String method, java.net.URI uri) { return null; }
public  io.restassured.response.Response request(java.lang.String method, java.net.URL url) { return null; }
public  io.restassured.response.Response get(java.lang.String path, java.util.Map pathParamsMap) { return null; }
public  io.restassured.response.Response post(java.lang.String path, java.util.Map pathParamsMap) { return null; }
public  io.restassured.response.Response put(java.lang.String path, java.util.Map pathParamsMap) { return null; }
public  io.restassured.response.Response delete(java.lang.String path, java.util.Map pathParamsMap) { return null; }
public  io.restassured.response.Response head(java.lang.String path, java.util.Map pathParamsMap) { return null; }
public  io.restassured.response.Response patch(java.lang.String path, java.util.Map pathParamsMap) { return null; }
public  io.restassured.response.Response options(java.lang.String path, java.util.Map pathParamsMap) { return null; }
public  io.restassured.specification.RequestSpecification params(java.lang.String firstParameterName, java.lang.Object firstParameterValue, java.lang.Object... parameterNameValuePairs) { return null; }
public  io.restassured.specification.RequestSpecification params(java.util.Map parametersMap) { return null; }
public  io.restassured.specification.RequestSpecification param(java.lang.String parameterName, java.lang.Object... parameterValues) { return null; }
public  io.restassured.specification.FilterableRequestSpecification removeParam(java.lang.String parameterName) { return null; }
public  io.restassured.specification.RequestSpecification param(java.lang.String parameterName, java.util.Collection<?> parameterValues) { return null; }
public  io.restassured.specification.RequestSpecification queryParam(java.lang.String parameterName, java.util.Collection<?> parameterValues) { return null; }
public  io.restassured.specification.FilterableRequestSpecification removeQueryParam(java.lang.String parameterName) { return null; }
public  io.restassured.specification.FilterableRequestSpecification removeHeader(java.lang.String headerName) { return null; }
public  io.restassured.specification.FilterableRequestSpecification removeCookie(java.lang.String cookieName) { return null; }
public  io.restassured.specification.FilterableRequestSpecification removeCookie(io.restassured.http.Cookie cookie) { return null; }
public  io.restassured.specification.FilterableRequestSpecification replaceHeader(java.lang.String headerName, java.lang.String newValue) { return null; }
public  io.restassured.specification.FilterableRequestSpecification replaceCookie(java.lang.String cookieName, java.lang.String value) { return null; }
public  io.restassured.specification.FilterableRequestSpecification replaceCookie(io.restassured.http.Cookie cookie) { return null; }
public  io.restassured.specification.FilterableRequestSpecification replaceHeaders(io.restassured.http.Headers headers) { return null; }
public  io.restassured.specification.FilterableRequestSpecification replaceCookies(io.restassured.http.Cookies cookies) { return null; }
public  io.restassured.specification.FilterableRequestSpecification removeHeaders() { return null; }
public  io.restassured.specification.FilterableRequestSpecification removeCookies() { return null; }
public  io.restassured.specification.RequestSpecification queryParams(java.lang.String firstParameterName, java.lang.Object firstParameterValue, java.lang.Object... parameterNameValuePairs) { return null; }
public  io.restassured.specification.RequestSpecification queryParams(java.util.Map parametersMap) { return null; }
public  io.restassured.specification.RequestSpecification queryParam(java.lang.String parameterName, java.lang.Object... parameterValues) { return null; }
public  io.restassured.specification.RequestSpecification formParam(java.lang.String parameterName, java.util.Collection<?> parameterValues) { return null; }
public  io.restassured.specification.FilterableRequestSpecification removeFormParam(java.lang.String parameterName) { return null; }
public  io.restassured.specification.RequestSpecification formParams(java.lang.String firstParameterName, java.lang.Object firstParameterValue, java.lang.Object... parameterNameValuePairs) { return null; }
public  io.restassured.specification.RequestSpecification formParams(java.util.Map parametersMap) { return null; }
public  io.restassured.specification.RequestSpecification formParam(java.lang.String parameterName, java.lang.Object... additionalParameterValues) { return null; }
public  io.restassured.specification.RequestSpecification urlEncodingEnabled(boolean isEnabled) { return null; }
public  io.restassured.specification.RequestSpecification pathParam(java.lang.String parameterName, java.lang.Object parameterValue) { return null; }
public  io.restassured.specification.RequestSpecification pathParams(java.lang.String firstParameterName, java.lang.Object firstParameterValue, java.lang.Object... parameterNameValuePairs) { return null; }
public  io.restassured.specification.RequestSpecification pathParams(java.util.Map parameterNameValuePairs) { return null; }
public  io.restassured.specification.FilterableRequestSpecification removePathParam(java.lang.String parameterName) { return null; }
public  io.restassured.specification.FilterableRequestSpecification removeNamedPathParam(java.lang.String parameterName) { return null; }
public  io.restassured.specification.FilterableRequestSpecification removeUnnamedPathParam(java.lang.String parameterName) { return null; }
public  io.restassured.specification.FilterableRequestSpecification removeUnnamedPathParamByValue(java.lang.String parameterValue) { return null; }
public  io.restassured.specification.RequestSpecification config(io.restassured.config.RestAssuredConfig config) { return null; }
public  io.restassured.specification.RequestSpecification keyStore(java.lang.String pathToJks, java.lang.String password) { return null; }
public  io.restassured.specification.RequestSpecification keyStore(java.io.File pathToJks, java.lang.String password) { return null; }
public  io.restassured.specification.RequestSpecification trustStore(java.lang.String path, java.lang.String password) { return null; }
public  io.restassured.specification.RequestSpecification trustStore(java.io.File path, java.lang.String password) { return null; }
public  io.restassured.specification.RequestSpecification trustStore(java.security.KeyStore trustStore) { return null; }
public  io.restassured.specification.RequestSpecification keyStore(java.security.KeyStore keyStore) { return null; }
public  io.restassured.specification.RequestSpecification relaxedHTTPSValidation() { return null; }
public  io.restassured.specification.RequestSpecification relaxedHTTPSValidation(java.lang.String protocol) { return null; }
public  io.restassured.specification.RequestSpecification filter(io.restassured.filter.Filter filter) { return null; }
public  io.restassured.specification.RequestSpecification filters(java.util.List<io.restassured.filter.Filter> filters) { return null; }
public  io.restassured.specification.RequestSpecification filters(io.restassured.filter.Filter filter, io.restassured.filter.Filter... additionalFilter) { return null; }
public  io.restassured.specification.RequestLogSpecification log() { return null; }
public  io.restassured.specification.RequestSpecification and() { return null; }
public  io.restassured.specification.RequestSpecification request() { return null; }
public  io.restassured.specification.RequestSpecification with() { return null; }
public  io.restassured.specification.ResponseSpecification then() { return null; }
public  io.restassured.specification.ResponseSpecification expect() { return null; }
public  io.restassured.specification.AuthenticationSpecification auth() { return null; }
@java.lang.Override() public  io.restassured.specification.RequestSpecification csrf(java.lang.String csrfTokenPath) { return null; }
@java.lang.Override() public  io.restassured.specification.RequestSpecification csrf(java.lang.String csrfTokenPath, java.lang.String csrfInputFieldName) { return null; }
@java.lang.Override() public  io.restassured.specification.RequestSpecification disableCsrf() { return null; }
public  io.restassured.specification.AuthenticationSpecification authentication() { return null; }
public  io.restassured.specification.RequestSpecification port(int port) { return null; }
public  io.restassured.specification.RequestSpecification body(java.lang.String body) { return null; }
public  io.restassured.specification.RequestSpecification baseUri(java.lang.String baseUri) { return null; }
public  io.restassured.specification.RequestSpecification basePath(java.lang.String basePath) { return null; }
public  io.restassured.specification.RequestSpecification proxy(java.lang.String host, int port) { return null; }
public  io.restassured.specification.RequestSpecification proxy(java.lang.String host) { return null; }
public  io.restassured.specification.RequestSpecification proxy(int port) { return null; }
public  io.restassured.specification.RequestSpecification proxy(java.lang.String host, int port, java.lang.String scheme) { return null; }
public  io.restassured.specification.RequestSpecification proxy(java.net.URI uri) { return null; }
public  io.restassured.specification.RequestSpecification proxy(io.restassured.specification.ProxySpecification proxySpecification) { return null; }
public  io.restassured.specification.RequestSpecification body(byte... body) { return null; }
public  io.restassured.specification.RequestSpecification body(java.io.File body) { return null; }
public  io.restassured.specification.RequestSpecification body(java.io.InputStream body) { return null; }
public  io.restassured.specification.RequestSpecification body(java.lang.Object object) { return null; }
public  io.restassured.specification.RequestSpecification body(java.lang.Object object, io.restassured.mapper.ObjectMapper mapper) { return null; }
public  io.restassured.specification.RequestSpecification body(java.lang.Object object, io.restassured.mapper.ObjectMapperType mapperType) { return null; }
public  io.restassured.specification.RequestSpecification contentType(io.restassured.http.ContentType contentType) { return null; }
public  io.restassured.specification.RequestSpecification contentType(java.lang.String contentType) { return null; }
public  io.restassured.specification.RequestSpecification noContentType() { return null; }
public  io.restassured.specification.RequestSpecification accept(io.restassured.http.ContentType contentType) { return null; }
public  io.restassured.specification.RequestSpecification accept(java.lang.String mediaTypes) { return null; }
public  io.restassured.specification.RequestSpecification headers(java.util.Map headers) { return null; }
public  io.restassured.specification.RequestSpecification headers(io.restassured.http.Headers headers) { return null; }
public  io.restassured.specification.RequestSpecification header(java.lang.String headerName, java.lang.Object headerValue, java.lang.Object... additionalHeaderValues) { return null; }
public  io.restassured.specification.RequestSpecification header(io.restassured.http.Header header) { return null; }
public  io.restassured.specification.RequestSpecification headers(java.lang.String firstHeaderName, java.lang.Object firstHeaderValue, java.lang.Object... headerNameValuePairs) { return null; }
public  io.restassured.specification.RequestSpecification cookies(java.lang.String firstCookieName, java.lang.Object firstCookieValue, java.lang.Object... cookieNameValuePairs) { return null; }
public  io.restassured.specification.RequestSpecification cookies(java.util.Map cookies) { return null; }
public  io.restassured.specification.RequestSpecification cookies(io.restassured.http.Cookies cookies) { return null; }
public  io.restassured.specification.RequestSpecification cookie(java.lang.String cookieName, java.lang.Object value, java.lang.Object... additionalValues) { return null; }
public  io.restassured.specification.RequestSpecification cookie(io.restassured.http.Cookie cookie) { return null; }
public  io.restassured.specification.RequestSpecification cookie(java.lang.String cookieName) { return null; }
public  io.restassured.specification.RedirectSpecification redirects() { return null; }
public  io.restassured.specification.RequestSpecification spec(io.restassured.specification.RequestSpecification requestSpecificationToMerge) { return null; }
public  io.restassured.specification.RequestSpecification specification(io.restassured.specification.RequestSpecification requestSpecificationToMerge) { return null; }
public  io.restassured.specification.RequestSpecification sessionId(java.lang.String sessionIdValue) { return null; }
public  io.restassured.specification.RequestSpecification sessionId(java.lang.String sessionIdName, java.lang.String sessionIdValue) { return null; }
public  io.restassured.specification.RequestSpecification multiPart(io.restassured.specification.MultiPartSpecification multiPartSpec) { return null; }
public  io.restassured.specification.RequestSpecification multiPart(java.lang.String controlName, java.io.File file) { return null; }
public  io.restassured.specification.RequestSpecification multiPart(java.io.File file) { return null; }
public  io.restassured.specification.RequestSpecification multiPart(java.lang.String controlName, java.io.File file, java.lang.String mimeType) { return null; }
public  io.restassured.specification.RequestSpecification multiPart(java.lang.String controlName, java.lang.Object object) { return null; }
public  io.restassured.specification.RequestSpecification multiPart(java.lang.String controlName, java.lang.Object object, java.lang.String mimeType) { return null; }
public  io.restassured.specification.RequestSpecification multiPart(java.lang.String controlName, java.lang.String filename, java.lang.Object object, java.lang.String mimeType) { return null; }
public  io.restassured.specification.RequestSpecification multiPart(java.lang.String name, java.lang.String fileName, byte... bytes) { return null; }
public  io.restassured.specification.RequestSpecification multiPart(java.lang.String name, java.lang.String fileName, byte[] bytes, java.lang.String mimeType) { return null; }
public  io.restassured.specification.RequestSpecification multiPart(java.lang.String name, java.lang.String fileName, java.io.InputStream stream) { return null; }
public  io.restassured.specification.RequestSpecification multiPart(java.lang.String name, java.lang.String fileName, java.io.InputStream stream, java.lang.String mimeType) { return null; }
public  io.restassured.specification.RequestSpecification multiPart(java.lang.String name, java.lang.String contentBody) { return null; }
public  io.restassured.specification.RequestSpecification multiPart(java.lang.String name, io.restassured.internal.NoParameterValue contentBody) { return null; }
public  io.restassured.specification.RequestSpecification multiPart(java.lang.String name, java.lang.String contentBody, java.lang.String mimeType) { return null; }
public  java.lang.Object newFilterContext(java.lang.Object assertionClosure, java.lang.Object filters, java.lang.Object properties) { return null; }
public  void assertCorrectNumberOfPathParams() { }
public  boolean shouldApplySSLConfig(java.lang.Object http, io.restassured.config.RestAssuredConfig cfg) { return false; }
public  java.lang.Object applyRestAssuredConfig(io.restassured.internal.http.HTTPBuilder http) { return null; }
public  java.lang.Object applySessionConfig(io.restassured.config.SessionConfig sessionConfig) { return null; }
public  java.lang.Object applyEncoderConfig(io.restassured.internal.http.HTTPBuilder httpBuilder, io.restassured.config.EncoderConfig encoderConfig) { return null; }
public  java.lang.Object applyHttpClientConfig(io.restassured.config.HttpClientConfig httpClientConfig) { return null; }
public  java.lang.Object applyRedirectConfig(io.restassured.config.RedirectConfig redirectConfig) { return null; }
public  java.lang.Object assembleBodyContent(java.lang.Object httpMethod) { return null; }
public  java.lang.Object mergeMapsAndRetainOrder(java.util.Map<java.lang.String, java.lang.Object> map1, java.util.Map<java.lang.String, java.lang.Object> map2) { return null; }
public  java.lang.Object setRequestHeadersToHttpBuilder(io.restassured.internal.http.HTTPBuilder http) { return null; }
public  void buildUnnamedPathParameterTuples(java.lang.Object... unnamedPathParameterValues) { }
public  java.lang.String partiallyApplyPathParams(java.lang.String path, boolean encodePath, java.util.List<java.lang.String> unnamedPathParams) { return null; }
public  void setResponseSpecification(io.restassured.specification.ResponseSpecification responseSpecification) { }
public  java.lang.String getBaseUri() { return null; }
public  java.lang.String getBasePath() { return null; }
public  java.lang.String getDerivedPath() { return null; }
public  java.lang.String getUserDefinedPath() { return null; }
public  java.lang.String getMethod() { return null; }
public  java.lang.String getURI() { return null; }
public  int getPort() { return 0; }
public  java.util.Map<java.lang.String, java.lang.String> getFormParams() { return null; }
public  java.util.Map<java.lang.String, java.lang.String> getPathParams() { return null; }
public  java.util.Map<java.lang.String, java.lang.String> getNamedPathParams() { return null; }
public  java.util.Map<java.lang.String, java.lang.String> getUnnamedPathParams() { return null; }
public  java.util.List<java.lang.String> getUnnamedPathParamValues() { return null; }
public  java.util.Map<java.lang.String, java.lang.String> getRequestParams() { return null; }
public  java.util.Map<java.lang.String, java.lang.String> getQueryParams() { return null; }
public  java.util.List<io.restassured.specification.MultiPartSpecification> getMultiPartParams() { return null; }
public  io.restassured.http.Headers getHeaders() { return null; }
public  io.restassured.http.Cookies getCookies() { return null; }
public  java.lang.Object getBody() { return null; }
public  java.util.List<io.restassured.filter.Filter> getDefinedFilters() { return null; }
public  io.restassured.config.RestAssuredConfig getConfig() { return null; }
public  org.apache.http.client.HttpClient getHttpClient() { return null; }
public  io.restassured.specification.ProxySpecification getProxySpecification() { return null; }
public  io.restassured.specification.FilterableRequestSpecification path(java.lang.String path) { return null; }
public  java.util.List<java.lang.String> getUndefinedPathParamPlaceholders() { return null; }
public  java.util.List<java.lang.String> getPathParamPlaceholders() { return null; }
public  java.lang.String getRequestContentType() { return null; }
@java.lang.Override() public  java.lang.String getContentType() { return null; }
@java.lang.Override() public  io.restassured.specification.RequestSpecification noFilters() { return null; }
@java.lang.Override() public  io.restassured.specification.RequestSpecification noFiltersOfType(java.lang.Class filterType) { return null; }
public  io.restassured.config.RestAssuredConfig restAssuredConfig() { return null; }
public static  java.util.List getPlaceholders(java.lang.String uri) { return null; }
public static  java.lang.String getDerivedPath(java.lang.String uri) { return null; }
public  java.lang.String getURI(java.lang.String uri) { return null; }
public  java.util.Map<java.lang.String, java.lang.String> getRedundantNamedPathParams() { return null; }
public  java.util.List<java.lang.String> getRedundantUnnamedPathParamValues() { return null; }
public  void removeUnnamedPathParamAtIndex(int indexOfParamName) { }
public  void setMethod(java.lang.String method) { }
private static enum EncodingTarget
  implements
    groovy.lang.GroovyObject {
BODY, QUERY;
public static final io.restassured.internal.RequestSpecificationImpl.EncodingTarget MIN_VALUE = null;
public static final io.restassured.internal.RequestSpecificationImpl.EncodingTarget MAX_VALUE = null;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
@groovy.transform.Generated() public  io.restassured.internal.RequestSpecificationImpl.EncodingTarget next() { return null; }
@groovy.transform.Generated() public  io.restassured.internal.RequestSpecificationImpl.EncodingTarget previous() { return null; }
@groovy.transform.Generated() public static final  io.restassured.internal.RequestSpecificationImpl.EncodingTarget $INIT(java.lang.Object... para) { return null; }
}
}
