package io.restassured.internal;

public class TestSpecificationImpl
  extends java.lang.Object  implements
    io.restassured.specification.RequestSender,    groovy.lang.GroovyObject {
;
public TestSpecificationImpl(io.restassured.specification.RequestSpecification requestSpecification, io.restassured.specification.ResponseSpecification responseSpecification) {}
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  io.restassured.response.Response get(java.lang.String path, java.lang.Object... pathParams) { return null; }
public  io.restassured.response.Response post(java.lang.String path, java.lang.Object... pathParams) { return null; }
public  io.restassured.response.Response put(java.lang.String path, java.lang.Object... pathParams) { return null; }
public  io.restassured.response.Response delete(java.lang.String path, java.lang.Object... pathParams) { return null; }
public  io.restassured.response.Response head(java.lang.String path, java.lang.Object... pathParams) { return null; }
public  io.restassured.response.Response patch(java.lang.String path, java.lang.Object... pathParams) { return null; }
public  io.restassured.response.Response options(java.lang.String path, java.lang.Object... pathParams) { return null; }
public  io.restassured.response.Response get(java.net.URI uri) { return null; }
public  io.restassured.response.Response post(java.net.URI uri) { return null; }
public  io.restassured.response.Response put(java.net.URI uri) { return null; }
public  io.restassured.response.Response delete(java.net.URI uri) { return null; }
public  io.restassured.response.Response head(java.net.URI uri) { return null; }
public  io.restassured.response.Response patch(java.net.URI uri) { return null; }
public  io.restassured.response.Response options(java.net.URI uri) { return null; }
public  io.restassured.response.Response get(java.net.URL url) { return null; }
public  io.restassured.response.Response post(java.net.URL url) { return null; }
public  io.restassured.response.Response put(java.net.URL url) { return null; }
public  io.restassured.response.Response delete(java.net.URL url) { return null; }
public  io.restassured.response.Response head(java.net.URL url) { return null; }
public  io.restassured.response.Response patch(java.net.URL url) { return null; }
public  io.restassured.response.Response options(java.net.URL url) { return null; }
public  io.restassured.response.Response get() { return null; }
public  io.restassured.response.Response post() { return null; }
public  io.restassured.response.Response put() { return null; }
public  io.restassured.response.Response delete() { return null; }
public  io.restassured.response.Response head() { return null; }
public  io.restassured.response.Response patch() { return null; }
public  io.restassured.response.Response options() { return null; }
public  io.restassured.response.Response request(io.restassured.http.Method method) { return null; }
public  io.restassured.response.Response request(java.lang.String method) { return null; }
public  io.restassured.response.Response request(io.restassured.http.Method method, java.lang.String path, java.lang.Object... pathParams) { return null; }
public  io.restassured.response.Response request(java.lang.String method, java.lang.String path, java.lang.Object... pathParams) { return null; }
public  io.restassured.response.Response request(io.restassured.http.Method method, java.net.URI uri) { return null; }
public  io.restassured.response.Response request(io.restassured.http.Method method, java.net.URL url) { return null; }
public  io.restassured.response.Response request(java.lang.String method, java.net.URI uri) { return null; }
public  io.restassured.response.Response request(java.lang.String method, java.net.URL url) { return null; }
public  io.restassured.response.Response get(java.lang.String path, java.util.Map pathParams) { return null; }
public  io.restassured.response.Response post(java.lang.String path, java.util.Map pathParams) { return null; }
public  io.restassured.response.Response put(java.lang.String path, java.util.Map pathParams) { return null; }
public  io.restassured.response.Response delete(java.lang.String path, java.util.Map pathParams) { return null; }
public  io.restassured.response.Response head(java.lang.String path, java.util.Map pathParams) { return null; }
public  io.restassured.response.Response patch(java.lang.String path, java.util.Map pathParams) { return null; }
public  io.restassured.response.Response options(java.lang.String path, java.util.Map pathParams) { return null; }
public  io.restassured.specification.RequestSpecification getRequestSpecification() { return null; }
public  io.restassured.specification.ResponseSpecification getResponseSpecification() { return null; }
}
