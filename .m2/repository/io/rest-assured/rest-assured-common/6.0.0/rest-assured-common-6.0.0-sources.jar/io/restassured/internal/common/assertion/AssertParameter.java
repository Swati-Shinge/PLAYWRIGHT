package io.restassured.internal.common.assertion;

public class AssertParameter
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
public static <T> T notNull(T object, java.lang.Class aClass) { return null; }
public static <T> T notNull(T object, java.lang.String parameterName) { return null; }
}
