package io.restassured.internal.common.assertion;

public abstract class HyphenQuoteFragmentEscaper
  extends java.lang.Object  implements
    io.restassured.internal.common.assertion.PathFragmentEscaper,    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
@java.lang.Override() public  java.lang.String escape(java.lang.String pathFragment) { return null; }
}
