package io.restassured.internal.common.path;

public class ObjectConverter
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
public static <T> T convertObjectTo(java.lang.Object object, java.lang.Class<T> explicitType) { return null; }
public static  boolean canConvert(java.lang.Object object, java.lang.Class type) { return false; }
}
