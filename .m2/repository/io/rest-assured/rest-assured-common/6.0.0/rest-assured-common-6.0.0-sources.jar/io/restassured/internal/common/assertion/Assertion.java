package io.restassured.internal.common.assertion;

public interface Assertion
 {
 java.lang.Object getResult(java.lang.Object object, java.lang.Object config);
 java.lang.String description();
}
