package io.restassured.internal.common.assertion;

public class AssertionSupport
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
;
@groovy.transform.Generated() @groovy.transform.Internal() @java.beans.Transient() public  groovy.lang.MetaClass getMetaClass() { return null; }
@groovy.transform.Generated() @groovy.transform.Internal() public  void setMetaClass(groovy.lang.MetaClass mc) { }
public static  java.lang.Object escapePath(java.lang.Object key, io.restassured.internal.common.assertion.PathFragmentEscaper... pathFragmentEscapers) { return null; }
public static  java.lang.Object hyphen() { return null; }
public static  java.lang.Object properties() { return null; }
public static  java.lang.Object classKeyword() { return null; }
public static  java.lang.Object attributeGetter() { return null; }
public static  java.lang.Object doubleStar() { return null; }
public static  java.lang.Object colon() { return null; }
public static  java.lang.Object integer() { return null; }
public static  java.lang.String generateWhitespace(int number) { return null; }
}
