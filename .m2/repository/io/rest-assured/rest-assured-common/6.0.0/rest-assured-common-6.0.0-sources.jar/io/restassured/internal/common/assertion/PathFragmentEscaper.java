package io.restassured.internal.common.assertion;

public interface PathFragmentEscaper
 {
 boolean shouldEscape(java.lang.String pathFragment);
 java.lang.String escape(java.lang.String pathFragment);
}
